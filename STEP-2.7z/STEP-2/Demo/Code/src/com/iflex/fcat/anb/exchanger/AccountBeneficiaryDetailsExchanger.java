package	com.iflex.fcat.anb.exchanger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.iflex.fcat.anb.dto.AccountBeneficiaryDetailsDTO;
import com.iflex.fcat.apps.exhg_fcr.FCRExchangerRoot;
import com.iflex.fcat.apps.exhg_fcr.RAccounts;
import com.iflex.fcat.xml.XmlBuilderParser;



public class 
	AccountBeneficiaryDetailsExchanger
extends 
	FCRExchangerRoot
{
	
	public Connection					l_host_conn							= null;

	private static final String
	SEL_ACCOUNT_DETAILS=" SELECT COD_CCY, BAL_BOOK,BAL_AVAILABLE "+
						" FROM CH_ACCT_MAST "+
						" WHERE COD_CUST=?";
	
	
	protected XmlBuilderParser
	xmlParser
	;
	
	private AccountBeneficiaryDetailsDTO		acctBenefDetailsDTO;
	
	public String
	cust_id
;
	protected void initRetailTransaction() {
		acctBenefDetailsDTO	=	(AccountBeneficiaryDetailsDTO)fcrDTORoot;
	}

	@Override
	protected short executeProcedure() throws Exception {
		return 0;
	}

	protected void doExchange() {
		try{
			populateAcctsDtls();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	protected void extractOutputValues() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected String getProcedureString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected String getProcedureParamString() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void setDTOValues() {
				
	}

	@Override
	protected void registerOutParameters() throws Exception {
		// TODO Auto-generated method stub
		
	}
	


	private void populateAcctsDtls () throws Exception {

			RAccounts			l_account			= RAccounts.getInstance ();
			PreparedStatement 	l_stmt 				= null;
			ResultSet			l_rs				= null;
			String				l_acct_ccy_code		= null; 
			double				l_amt_book_bal		= 0,
								l_amt_avail_bal		= 0;
								
			try {				
				l_stmt		=  dbConnection.prepareStatement (SEL_ACCOUNT_DETAILS);
				l_stmt.setString (1, fcrDTORoot.loginCustId);

				l_rs = l_stmt.executeQuery();

				while (l_rs.next ()) {
					l_amt_avail_bal			= l_rs.getDouble ("BAL_AVAILABLE");
					l_amt_book_bal			= l_rs.getDouble ("BAL_BOOK");
					l_acct_ccy_code            = l_rs.getString("COD_CCY");
					

					l_account.accountCurr	=l_acct_ccy_code;
					l_account.book_bal=  l_amt_book_bal	;
					l_account.avail_bal=  	l_amt_avail_bal	;
									
					acctBenefDetailsDTO.vec_accounts.add (l_account);
				}
			} finally {
				try {
					l_rs.close ();
				} catch (Exception e) {
				}
				try {
					l_stmt.close ();
				} catch (Exception e) {
				}
				l_rs	= null;
				l_stmt	= null;		
				
				try {
					RAccounts.putInstance (l_account);
				} catch (Exception e1){
				}
			} 
		}
}
	