package	com.iflex.fcat.anb.dto;


import java.util.ArrayList;
import java.util.Vector;

import com.iflex.fcat.apps.exhg_fcr.FCRDTORoot;



public class 
	AccountBeneficiaryDetailsDTO 
extends 
	FCRDTORoot
{ 

	public ArrayList
		vec_accounts
	;

	@Override
	protected void initializeDTO() {
		vec_accounts	=	new ArrayList();
	}
	
}
