package	com.iflex.fcat.anb.bean;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import org.w3c.dom.Element;

import com.iflex.fcat.anb.dto.AccountBeneficiaryDetailsDTO;
import com.iflex.fcat.apps.exhg_fcr.RAccounts;
import com.iflex.fcat.fcy.apps.FCYRoot;
import com.iflex.fcat.fcy.validation.apps.FCYErrors;


public class 
	AccountBeneficiaryDetailsBean 
extends 
	FCYRoot 
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String l_custID	;

	private static final String TXN_ANB="ANB";


	private static final String SEL_BENEF=" SELECT BENEF_NAME, BENEF_ACCT_TYPE"+
											" FROM RR_TP_BENEFICIARY" +
											" WHERE IDUSER=? "+
											" order by BENEF_ACCT_TYPE";
											
	@Override
	protected void onValidationFailedEvent(
		ArrayList<FCYErrors> customValidationErrorCodes) throws Exception {
		
	}

	@Override
	protected void buildResponseMessage() throws Exception {
		
	}

	@Override
	protected void initTransaction() {
		l_custID	=	null;		
	}

	@Override
	protected int processFromLDB() throws Throwable {
		return 0;
	}
	protected void doPostProcess() throws Exception {
		
		getBeneficiaryDetails(); 
		getAccountBalance();
	
	}
		
	@Override
	protected void initializeDTOInstance() {
		dtoInstance = new AccountBeneficiaryDetailsDTO();
	}
	
	protected void getBeneficiaryDetails()
	throws Exception {

        
		PreparedStatement	l_stmt 			= null;
		ResultSet			l_rs 			= null;
		Element				l_beneflist		= null;
		Element             l_element		= null;
		String              benef_type		= null;
		l_stmt= dbConnection.prepareStatement (SEL_BENEF);
		l_stmt.setString(1,loginCustId);
		l_rs 		= l_stmt.executeQuery ();
		
		l_beneflist	= xmlParser.createElement ("beneflist", null, rootElement);
         
		try {

       		while (l_rs.next ()) {
				l_element = xmlParser.createElement (
						"beneficiery"
					,	null
					,	l_beneflist
					);
				
				l_element.setAttribute (
						"beneficieryname"
					,  	l_rs.getString ("BENEF_NAME")
					);
				
				benef_type=	l_rs.getString ("BENEF_ACCT_TYPE");
				
				if(benef_type.equals("I"))
						{
				l_element.setAttribute	(
						"beneficierytype"
					, "Internal"
					);
						}
				
				else 
					
				{
					l_element.setAttribute	(
							"beneficierytype"
						, 	"External"
						);
				}
					
       		}
       		
       		    		
		}		
		finally {
			try {
				l_rs.close ();
			    }
		catch (Exception e) {
			   }
		
		try {
			l_stmt.close ();
		} catch (Exception e) {
		}

		l_rs	= null;
		l_stmt	= null;
		}
	}
	private void getAccountBalance() {

		ArrayList<RAccounts> l_accountDetails	=	new ArrayList<RAccounts>();
		RAccounts			l_account			= null;
		
		
		l_accountDetails	=	((AccountBeneficiaryDetailsDTO) dtoInstance).vec_accounts;
		try {
			
			Element				l_acctist		= null;
			Element             l_element		= null;
						
			//Element l_acctlist	= null;
			l_acctist	=	xmlParser.createElement (
											"acctlist",	null, rootElement);
			if(l_accountDetails != null){
				for (int i=0; i< l_accountDetails.size(); i++)
				{
					l_account	=	(RAccounts)l_accountDetails.get(i);
					
					l_element = xmlParser.createElement (
							"account"  
						,	null 
						,	l_acctist
						);
	
						l_element.setAttribute (
							"acct_cur_name"
						,  	l_account.accountCurr
						);
	
						l_element.setAttribute	(
							"bal_book" 
						, String.valueOf(l_account.book_bal));
	
						l_element.setAttribute	(
							"bal_available" 
						,	 String.valueOf(l_account.avail_bal));
				}
			}
		}
		catch (Exception e) {
				e.printStackTrace();
		}
	}
}
//------------------------------------------------------------
//-----------------------------EOF----------------------------
//------------------------------------------------------------

