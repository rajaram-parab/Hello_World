/*------------------------------------------------------------------------------

This source is part of the FLEXCUBE@ Java App Server Software System and is
copyrighted by i-flex Solutions Limited.

All rights reserved.  No part of this work may be reproduced, stored in a
retrieval system, adopted or transmitted in any form or by any means,
electronic, mechanical, photographic, graphic, optic recording or otherwise,
translated in any language or computer language, without the prior written
permission of i-flex Solutions Limited.

i-flex Solutions Limited.
10-11, SDF I, SEEPZ, Andheri (East),
Mumbai - 400 096.
India

Copyright � 2005 i-flex Solutions Limited.

Version:	$Header: /FC@ Retail 3.0.1/source/com/iflex/fcat/apps/exhg_fcr/RAccounts.java 2     4/16/05 5:44p Sangitab $

Modification History

Date		Version		Author			Description
----------	-----------	--------------- ----------------------------------------
22.03.2005	1.1			Anurag			Added valriables for account currecny code and branch.
------------------------------------------------------------------------------*/
package com.iflex.fcat.apps.exhg_fcr;
//------------------------------------------------------------------------------
import  java.sql.Date;
import  com.iflex.fcat.infra.JFCache;
//------------------------------------------------------------------------------
/**
This class encapsulates values for account information.For each field this class
has an instance variable.This class gets an instance from the JFCache class
which could be used in the exchanger class and avoid re-instancing , when
multiple values are fetched.Also uses the get and put instance methods and the
static initializer.
**/
public class
	RAccounts
{
	//-------------------------------------------------------------------------
	/**
	Class name.
	**/
	public static final String
		CLASS_NAME		= RAccounts.class.getName ()
	;
	//-------------------------------------------------------------------------
	/**
	Instance variable to store the account number.
	**/
	public String
		accountNo
	;
	/**
	Instance variable to store the account deposit number.
	**/
	public int
		depNo
	;
	/**
	Instance variable to store the TD account original deposit number.
	**/
	public int
		orgDepNo
	;
	/**
	Instance variable to store the account type.
	**/
	public String
		accountType
	;
	/**
	Instance variable to store the account currency.
	**/
	public String
		accountCurr
	;
	/**
	Instance variable to store the account currency code.
	**/
	public int 
	accountCurrCode
	;
	/**
	Instance variable to store the brance code.
	**/
	public String
		branchCode
	;
	/**
	Instance variable to store the branch name.
	**/
	public String
		branchName
	;
	/**
	Instance variable to store the product code.
	**/
	public String
		productCode
	;
	/**
	This instance variable stores product name.
	**/
	public String
		productName
	;
	/**
	Instance variable to store the code holder status.
	**/
	public String
		codHolderSts
	;
	/**
	Instance variable to store the account status.
	**/
	public int
		codAcctSts
	;
	/**
	Instence variable to store the account opening date.
	**/
	public Date
		acctOpenDate
	;
	/**
	This variable, when set to "Y" indicates that an account can be accessed via net.
	**/
	public String
		netAllowed
	;
	/**
	This variable stores the type of customer/account relationship.
	**/
	public String
		custAcctRel
	;
	//-------------------------------------------------------------------------
	/**
	These variables will be used for savings account.
	**/
	/**
	Instance variable to store the current balance.
	**/
	public double
		currentBal
	;
	/**
	Instance variable to store the minimum balance required.
	**/
	public double
		minBalReq
	;
	/**
	Instance variable to store overdraft limit.
	**/
	public double
		odLimit
	;
	/**
	Instance variable to store account category ( joint / single)
	**/
	public String
		flgjointAcct
	;
	/**
	Instance variable to store whether product associate with this account has
	over draft facility.
	**/
	public char
		productType
	;
	/**
	Instance variable to store whether the CASA account is the default account.
	**/
	public boolean
		defaultAcct
	;
	//-------------------------------------------------------------------------
	/**
	These variable will be used for card accounts.
	**/
	/**
	Instance variable to store card type.
	**/
	public String
		cardType
	;
	/**
	Instance variable to store the credit limit of the card account.
	**/
	public double
		creditLimit
	;
	/**
	Instance variable to store the date of expiry of the account.
	**/
	public Date
		dateExpiry
	;
	/**
	Instance variable to store the outstanding amount.
	**/
	public double
		outstandingAmt
	;
	//-------------------------------------------------------------------------
	/**
	These variables will be used for Loan accounts.
	**/
	/**
	Instance variable to store the loan amount.
	**/
	public double
		loanAmt
	;
	/**
	Instance variable to store date of maturity of the account.
	**/
	public Date
		datMaturity
	;
	/**
	Instance variable to store the rate of interest
	**/
	public double
		rateInt
	;
	/**
	Instance variable to store penalty interest.
	**/
	public double
		penalInt
	;
	/**
	Instance variable to store stage of loan.
	**/
	public int
		codThisStage
	;
	public double book_bal;
	
	public double avail_bal;
	//-------------------------------------------------------------------------
	/**
	These variables will be used for term deposit accounts.
	**/
	/**
	Instance varibale to store the initial deposit amount.
	**/
	public double
		initialDeposit
	;
	
	public String acct_title;
	//-------------------------------------------------------------------------
	/**
	The static initializer that creates the cache for this class.
	**/
	static {
		try {

		JFCache.createCache (
			RAccounts.CLASS_NAME
		,	RAccounts.class
		);
		} catch (Exception e) {
			e.printStackTrace ();
		}

	}
	//-------------------------------------------------------------------------
	/**
	This method is used to get the instance from the cahce. If no instance is
	present then a new instance is created.
	**/
	public static RAccounts getInstance ()
	throws Exception {

		RAccounts	l_raccounts	=	null;

		Object l_instance = JFCache.getObject (RAccounts.CLASS_NAME);

		if (l_instance == null) {
			l_raccounts = new RAccounts ();
		} else {
			l_raccounts = (RAccounts) l_instance;
		}

		return l_raccounts.initInstance ();

	}
	//-------------------------------------------------------------------------
	/**
	This method is used to put the instance back on the stack for furthur
	reuse.
	**/
	public static void putInstance (
		RAccounts	p_instance
	) throws Exception {

		JFCache.putObject (RAccounts.CLASS_NAME, p_instance);

	}
	//-------------------------------------------------------------------------
	/**
	Ths method initializes the inistance variables of the object to default
	values.
	**/
	private RAccounts initInstance () {

		accountNo		= null;
		depNo           = 0;
		orgDepNo		= 0;
		accountType		= null;
		accountCurr		= null;
		accountCurrCode = 0;
		branchCode		= null;
		productCode		= null;
		productName		= null;
		codHolderSts	= null;
		codAcctSts		= -1;
		acctOpenDate	= null;
		netAllowed		= null;
		custAcctRel		= null;
		currentBal		= 0;
		minBalReq		= 0;
		odLimit			= 0;
		flgjointAcct	= null;
		productType		= ' ';
		cardType		= null;
		creditLimit		= 0;
		dateExpiry		= null;
		outstandingAmt	= 0;
		loanAmt			= 0;
		datMaturity		= null;
		rateInt			= 0;
		penalInt		= 0;
		initialDeposit	= 0;
		codThisStage	= -1;
		defaultAcct		= false;
		branchName		= null;
		acct_title=null;
		book_bal=0;
		avail_bal=0;
		return this;

	}
	//-------------------------------------------------------------------------
}
//------------------------------------------------------------------------------
//
//	End of file
//
//------------------------------------------------------------------------------
